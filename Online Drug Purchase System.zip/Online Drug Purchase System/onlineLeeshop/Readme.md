运行方法：

创建数据库  leeshop

在  application-demo.yml  修改对应的数据库账号和密码

导入数据库文件  leeshop.sql

最后用 BookshopApplication 启动即可

后台管理员登录是写死的

账号 admin

密码 123456