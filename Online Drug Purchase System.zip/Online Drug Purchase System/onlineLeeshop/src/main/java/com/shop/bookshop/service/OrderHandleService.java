package com.shop.bookshop.service;

import com.shop.bookshop.pojo.Order;

import java.util.List;


public interface OrderHandleService {


    void createOrder(Order order);


    int deleteOrderById(Integer orderId);



   List<Order> getOrdersByUserId(Integer userId,Integer page ,Integer limit);


    List<Order> getAllOrdersByPage(Integer page, Integer limit);

}
