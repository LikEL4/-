package com.shop.bookshop.service;

import java.util.List;

import com.shop.bookshop.pojo.Category;

public interface CategoryService {


	int deleteByByCategoryCode(String categoryCode);

	int insert(Category record);

	Category selectByByCategoryCode(String categoryCode);

	int updateByCategoryCode(Category record);


	List<Category> selectAll(Integer page, Integer limit);
}
