package com.shop.bookshop.controller;

import com.github.pagehelper.PageInfo;
import com.shop.bookshop.pojo.Book;
import com.shop.bookshop.pojo.Category;
import com.shop.bookshop.service.BookDisplayService;
import com.shop.bookshop.util.ResultCode;
import com.shop.bookshop.util.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Controller
@RequestMapping("/index")
public class BookDisplayController {

    @Autowired
    private BookDisplayService bookDisplayService;


    @GetMapping("/category")
    @ResponseBody
    public ResultVO getCategories() {
        List<Category> categories = bookDisplayService.getAllCategories();
        return new ResultVO(ResultCode.SUCCESS,categories);
    }


    @GetMapping("/books")
    @ResponseBody
    public ResultVO getBooksByCategoryCode(@RequestParam(required = false) String categoryCode, @RequestParam(required = false) Integer page, @RequestParam(required = false) Integer limit) {
        List<Book> books = bookDisplayService.getBooksByCategoryCode(page==null?1:page, limit==null?10:limit, categoryCode);
        PageInfo pageInfo = new PageInfo(books);
        return new ResultVO(ResultCode.SUCCESS, (int) pageInfo.getTotal(),books);
    }


    @GetMapping("/books/details/{bookId}")
    public String bookDetailsView(@PathVariable("bookId") Integer bookId, Model model) {
        Book book = bookDisplayService.getBookDetailsByBookId(bookId);
        model.addAttribute("book", book);
        return "details";
    }


    @GetMapping("/books/search")
    @ResponseBody
    public ResultVO searchBook(@RequestParam(required = true) String bookName) {
        List<Book> books = bookDisplayService.searchBooksByBookName(1, 10, bookName);
        PageInfo pageInfo = new PageInfo(books);
        return new ResultVO(ResultCode.SUCCESS, (int) pageInfo.getTotal(), books);
    }



}
