layui.use(['element', 'jquery', 'layer', 'laytpl', 'laypage', 'form'], function () {
    var $ = layui.jquery,
        layer = layui.layer,
        laytpl = layui.laytpl,
        laypage = layui.laypage,
        form = layui.form,
        element = layui.element;


    window.order_submit_popup = function (orderItemData) {
        var form_str = '<form class="layui-form" lay-filter="orderVal" style="margin: 20px"> '
            + '<div class="layui-form-item"> '
            + '<label class="layui-form-label">Receiver</label> '
            + ' <div class="layui-input-block"> '
            + '<input type="text" name="consigneeName" required  lay-verify="required" placeholder="Please enter the consignee name" autocomplete="off" class="layui-input"></div> '
            + '</div><div class="layui-form-item layui-form-text"> '
            + '<label class="layui-form-label">Shipping address</label><div class="layui-input-block"> '
            + '<textarea name="address" placeholder="Please enter the delivery address" class="layui-textarea"></textarea>'
            + '</div></div><div class="layui-form-item"> '
            + '<label class="layui-form-label">zip code</label><div class="layui-input-block"> '
            + '<input type="text" name="zip" required  lay-verify="required" placeholder="Please enter a zip code" autocomplete="off" class="layui-input"> '
            + '</div></div><div class="layui-form-item"> '
            + '<label class="layui-form-label">phone number</label><div class="layui-input-block"> '
            + '<input type="text" name="phoneNumber" required  lay-verify="required" placeholder="Please enter the phone number" autocomplete="off" class="layui-input"> '
            + '</div></div>';

        $.getJSON("/checkLoggedIn", function (result) {
            if(result.code!=0){
                return layer.msg(result.msg, {icon: 2});
            }
            return layer.open({
                type:1,
                title: 'Order information submission',
                content: form_str,
                area: ['500px'],
                btn: ['Submit order', 'Cancel'],
                btnAlign: 'c',
                yes: function (index) {
                    var orderData = form.val("orderVal");
                    console.log(orderItemData);
                    orderData['orderItems'] = orderItemData;
                    console.log(orderData);
                    $.ajax({
                        url: '/order/submit',
                        type: 'post',
                        contentType: 'application/json',
                        data: JSON.stringify(orderData),
                        dataType: 'json',
                        success: function (res) {
                            if (res.code != 0) {
                                return layer.msg(res.msg, {icon: 2});
                            }
                            return layer.msg("Orders submitted successfully", {icon: 1, time: 1500}, function () {
                                window.location.href=res.data;
                            });
                        },
                        error: function () {
                            return layer.msg("Server error, please try again later", {icon: 2});
                        }
                    });
                },
                btn2: function (index) {
                    layer.close(index);
                },
                success: function () {
                    form.render();
                }
            });
        });
    }


    window.calculate = function (price, quantity) {
        return Math.floor(parseFloat(price * 100 * quantity)) / 100;
    }

});