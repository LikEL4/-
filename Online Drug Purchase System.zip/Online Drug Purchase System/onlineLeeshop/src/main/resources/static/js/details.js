layui.use(['element', 'jquery', 'layer', 'laytpl','laypage','form','table'], function() {
	var $ = layui.jquery,
		layer = layui.layer,
		laytpl = layui.laytpl,
		laypage=layui.laypage,
		form=layui.form,
		element = layui.element,
		table = layui.table;
		

		var str=window.location.pathname;
		var bookId=str.substring(str.lastIndexOf("/")+1);


		$("#buyNowBtn").click(function(){
			let data=[];
			let quantity=$("#quantity").val();
			if(quantity==0){
				return layer.msg('At least one is required to purchase',{icon:5});
			}
			let price=$("#price").text();
			data.push({
				'cartId':null,
				'bookId':bookId,
				'price':parseFloat(price),
				'quantity':quantity
			});
			console.log(data);
			order_submit_popup(data);
			
		});
		

		$("#addCartBtn").click(function(){
			let quantity=$("#quantity").val();
			if(quantity==0){
				return layer.msg('At least one item must be purchased to add to cart',{icon:5});
			}
			let price=$("#price").text();
			let data={
				'bookId':bookId,
				'price':parseFloat(price),
				'quantity':quantity
			};
			$.post('/cart/list', data, function (res) {
				if (res.code != 0) {
					return layer.msg(res.msg,{icon:2});
				}
				return layer.msg("Added successfully, please go to the shopping cart to view",{icon:1});
			});
		});
		

		window.check=function(obj,price){
			var qty=$(obj).val();
			if(qty<0||qty==''){
				layer.msg("Input must be greater than or equal to 0");
				$(obj).val(0);
				qty=0;
			}
			if(qty>10){
				layer.msg("Limit 10 pieces per user");
				$(obj).val(10);
				qty=10;
			}
			$("#totalAccount").text("¥"+Math.floor(parseFloat(price*100 *qty))/100);
		}
});