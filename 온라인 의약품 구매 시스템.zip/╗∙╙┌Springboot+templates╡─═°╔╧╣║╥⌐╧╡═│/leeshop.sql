/*
 Navicat Premium Data Transfer

 Source Server         : 本机
 Source Server Type    : MySQL
 Source Server Version : 80030 (8.0.30)
 Source Host           : localhost:3306
 Source Schema         : leeshop

 Target Server Type    : MySQL
 Target Server Version : 80030 (8.0.30)
 File Encoding         : 65001

 Date: 10/06/2023 19:29:25
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`  (
  `book_id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '书籍编号',
  `category_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '书籍分类代码',
  `book_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '书籍名称',
  `isbn` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ISBN',
  `author` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '作者',
  `press` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '出版社',
  `pub_date` date NOT NULL COMMENT '出版日期',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '书籍图片',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '书籍描述',
  `price` decimal(10, 2) UNSIGNED NOT NULL COMMENT '书籍单价',
  `stock` int UNSIGNED NOT NULL COMMENT '书籍库存',
  `create_time` datetime NULL DEFAULT NULL COMMENT '上架时间',
  PRIMARY KEY (`book_id`) USING BTREE,
  UNIQUE INDEX `book_id`(`book_id` ASC) USING BTREE,
  INDEX `category_code`(`category_code` ASC) USING BTREE,
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`category_code`) REFERENCES `category` (`category_code`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 1066 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES (1001, 'Antiviral', '몸살감기약', '9787555257035', '12개월', '약국', '2023-03-31', '1.jpg', '몸살감기약, 매우 친절합니다. 감기에 걸리면 바로 마셔요.', 7500.00, 93, '2023-04-21 20:12:00');
INSERT INTO `book` VALUES (1038, 'skin', '로시놀', '1231321', '24개월', '약국', '2023-04-06', '2.jpg', '무좀에 걸리면 써요', 7500.00, 44, '2023-04-21 22:24:38');
INSERT INTO `book` VALUES (1039, 'Antiviral', '콜대원', '1312352131', '18개월', '약국', '2023-04-05', '3.jpg', '진해, 거담, 천식 완화, 염증 완화요', 5300.00, 64, '2023-04-22 10:34:25');
INSERT INTO `book` VALUES (1040, 'skin', '아렉스', '42131231', '12개월', '약국', '2023-04-06', '4.png', '월경활락산, 냉통, 혈액활혈, 어혈해소입니다.', 2500.00, 22, '2023-04-22 10:40:24');
INSERT INTO `book` VALUES (1041, 'children', '소아 폐열 기침 천식 경구용 수액', '42313312', '12개월', '약국', '2023-04-18', '5.png', '아이가 기침을 하면 항상 좋지 않습니다. 대부분 폐열입니다. 해바라기표 소아 폐열 기침으로 천식하는 경구액은 반드시 좋습니다!', 4500.00, 78, '2023-04-23 11:07:18');
INSERT INTO `book` VALUES (1042, 'children', '소아 감기 알갱이', '753342', '36개월', '약국', '2023-04-15', '6.jpg', '아이가 감기에 걸리면 999아기 감기 알갱이를 사용', 2800.00, 77, '2023-04-23 11:08:33');
INSERT INTO `book` VALUES (1043, 'children', '소아용 해열 경구용액', '96485948', '36개월', '약국', '2023-04-01', '7.jpg', '아이가 열이 나면 어떡해요, 바로 어린이용 해열제를 드세요.', 5300.00, 78, '2023-04-23 11:09:39');
INSERT INTO `book` VALUES (1044, 'children', '소아 폐청정 및 가래약', '732452', '24개월', '약국', '2023-03-10', '8.jpg', '소아 청폐화담 경구액은 열을 내리고 가래를 삭이며 기침을 멎게 하고 천식을 가라앉히는 중국 특허 의약품으로 마황, 전호, 황금, 들깨(볶음), 석고, 쓴 아몬드(껍질을 벗기고 볶음), 꽃다지, 대나무로 구성되어 있습다.', 3400.00, 56, '2023-04-23 14:11:09');
INSERT INTO `book` VALUES (1045, 'infect', '트리겔 현탁액', '542131', '36개월', '약국', '2023-02-17', '9.jpg', '제산제 : 위산중화, 위내 통증 및 궤양형성 방지제', 5000.00, 47, '2023-04-23 14:13:08');
INSERT INTO `book` VALUES (1046, 'skin', '아바미스나잘스프레이', '231939182', '36개월', '약국', '2023-04-15', '10.jpg', '성인 및 2세 이상의 소아에서 계절성 또는 통년성 알레르기 비염 증상의 치료', 4000.00, 67, '2023-04-23 14:14:32');
INSERT INTO `book` VALUES (1047, 'Antiviral ', '타이레놀', '2131231', '36개월', '약국', '2023-02-16', '11.jpg', '감기로 인한 발열 및 동통(통증), 두통, 신경통, 근육통, 월경통, 염좌통(삔 통증)', 2500.00, 23, '2023-04-23 14:16:11');
INSERT INTO `book` VALUES (1048, 'Digestion', '평생환에프', '12341241', '36개월', '약국', '2023-04-19', '12.jpg', '식체(위체) 경향이 있는 다음 증상 : 식욕감퇴(식욕부진)', 2000.00, 57, '2023-04-23 14:20:12');
INSERT INTO `book` VALUES (1049, 'skin', '피엠네일라카', '2167534433', '24개월', '약국', '2023-03-18', '13.jpg', '손발을 씻고 건조시킨 후 하루에 한번 얇은 막이 형성되도록 환부(질환부위)에 바른다. 손발톱전체와 손발톱 주위 5mm의 피부, 가능하면 손발톱끝의 아래부분에 바른다. 30초 정도 건조 시킨 후 적어도 6시간 동안은 씻지 않아야 하므로 취침 전에 바르도록 한다. 이 약은 유기용매나 긁어내지 않고 물로도 충분히 제거된다. 만약 의도치 않게 물에 씻었다면 이 약을 다시 바른다.', 3000.00, 78, '2023-04-23 14:25:49');
INSERT INTO `book` VALUES (1050, 'Antiviral ', '타치온 정', '723423', '36개월', '약국', '2023-03-12', '14.jpg', '약물중독, 자가중독,성인 : 글루타티온으로서 1회 50-100mg, 1일 1-3회 복용한다.\r\n\r\n연령, 증상에 따라 적절히 증감한다.', 4000.00, 69, '2023-04-23 14:27:59');
INSERT INTO `book` VALUES (1051, 'Antiviral ', '래피콜', '732423', '36개월', '약국', '2023-04-16', '15.jpg', '감기의 제증상(여러증상)(콧물, 코막힘, 재채기, 인후(목구멍)통, 기침, 가래, 오한(춥고 떨리는 증상), 발열, 두통, 관절통, 근육통)의 완화', 3000.00, 20, '2023-04-23 14:29:59');
INSERT INTO `book` VALUES (1052, 'Antiviral ', '판콜에이내복액', '64123', '18개월', '약국', '2023-03-12', '16.jpg', '감기 제증상(여러 증상) [콧물, 코막힘, 재채기, 인후(목구멍)통, 기침, 가래, 오한(춥고 떨리는 증상), 발열, 두통, 관절통, 근육통]의 완화', 2300.00, 67, '2023-04-23 14:37:35');
INSERT INTO `book` VALUES (1053, 'infect', '그날엔 정', '7243112', '36개월', '약국', '2023-03-20', '17.jpg', '두통, 치통, 발치(이를 뽑음)후 동통(통증), 인후(목구멍)통, 귀의 통증, 관절통, 신경통, 요(허리)통, 근육통, 견통(어깨통증), 타박통, 골절통, 염좌통(삔 통증), 생리통, 외상(상처)통의 진통；오한, 발열시의 해열', 3000.00, 88, '2023-04-23 14:43:40');
INSERT INTO `book` VALUES (1054, 'Digestion', '겔포스엠', '617485464', '24개월', '약국', '2023-01-09', '18.jpg', '위산과다(위염, 위·십이지장궤양에 관련된 것도 포함), 속쓰림, 위부불쾌감, 위부팽만감, 체함, 구역, 구토, 위통, 신트림', 2500.00, 65, '2023-04-23 14:46:22');
INSERT INTO `book` VALUES (1055, 'infect', '아르날 정', '97579539', '36개월', '약국', '2023-03-01', '19.jpg', '알레르기성 비염, 알레르기성 결막염, 만성 두드러기, 피부 가려움증 등', 1500.00, 97, '2023-04-23 14:51:13');
INSERT INTO `book` VALUES (1056, 'skin', '후시딘연고', '74497456', '18개월', '약국', '2023-04-01', '20.jpg', '유효균종：포도구균, 연쇄구균, 코리네박테륨, 클로스트리듐；적응증： - 농피증(농가진, 감염성습진양피부염, 심상성여드름(보통여드름), 모낭염, 종기 및 종기증, 화농성한선염, 농가진성습진), 화상ㆍ외상ㆍ봉합창ㆍ식피창에 의한 2차 감염', 3500.00, 56, '2023-04-23 14:54:16');
INSERT INTO `book` VALUES (1057, 'infect', '썬스펜 8시간', '3684322', '18개월', '약국', '2023-02-01', '21.jpg', '해열 및 감기에 의한 동통(통증)과 두통, 치통, 근육통, 허리동통(통증), 생리통, 관절통의 완화', 6000.00, 63, '2023-04-23 14:56:13');
INSERT INTO `book` VALUES (1058, 'Digestion', '이진팜 정', '312747433', '18개월', '약국', '2023-02-10', '22.jpg', '소화불량, 식욕감퇴(식욕부진), 과식, 체함, 소화촉진, 소화불량으로 인한 위부팽만감, 정장, 변비, 묽은 변, 복부팽만감, 장내이상발효', 3800.00, 189, '2023-04-23 15:30:37');
INSERT INTO `book` VALUES (1059, 'Digestion', '雷贝拉唑', '6789433', '36개월', '약국', '2023-01-14', '23.jpg', '다음의 위식도 역류의 증상 개선 : 산 역류,속쓰림,위 내용물의 역류로 인한 소화불량 (예를 들어 식사 후, 임신 중, 역류성 식도염과 동반하는 경우의)', 4000.00, 89, '2023-04-23 15:34:21');
INSERT INTO `book` VALUES (1060, 'skin', '쎄레톤크림', '69482423', '18개월', '약국', '2023-03-09', '24.jpg', '2차 감염된 알레르기성 또는 염증성 피부질환: 습진, 접촉피부염, 지루피부염, 아토 피피부염, 광피부염, 만성단순태선, 간찰진, 박탈피부염, 가려움, 건선 -;1도 화상', 3800.00, 90, '2023-04-23 15:40:30');
INSERT INTO `book` VALUES (1061, 'skin', '페리덱스연고', '21524235', '18개월', '약국', '2023-03-21', '25.jpg', '다음 질환에 의한 염증의 완화 : 미란[짓무름] 또는 궤양을 수반하는 난치성 구내염[입안염] 및 설염[혀염]', 300.00, 97, '2023-04-23 15:42:18');
INSERT INTO `book` VALUES (1062, 'spirit', '몽모랑시 타트체리', '746128931', '36개월', '약국', '2023-03-09', '26.jpg', '불면증 해소, 수면주기 일정화 및 수면유도를 통한 생체리듬 조절', 7500.00, 23, '2023-04-23 15:45:15');
INSERT INTO `book` VALUES (1063, 'skin', '현대에어파스맥스에어로솔', '5231251', '36개월', '약국', '2023-03-26', '27.jpg', '삔데, 멍든데, 타박상, 근육통 치료의 보조', 17000.00, 78, '2023-04-26 10:09:42');
INSERT INTO `book` VALUES (1064, 'infect', '멘소래담 로션', '785324', '18개월', '약국', '2023-03-15', '28.jpg', '- 다음 증상의 진통ㆍ소염 : 삠, 타박상, 근육통, 관절통, 골절통, 요통, 어깨결림, 신경통, 류마티스통증；- 피부 가려움, 벌레 물린데；- 동창', 4000.00, 42, '2023-04-26 10:10:39');
INSERT INTO `book` VALUES (1065, 'spirit', '우황청심원액', '34111', '12개월', '약국', '2023-05-04', '29.jpg', '뇌졸중(전신마비, 사지마비, 언어장애, 혼수상태, 황홀경, 안면마비), 고혈압, 동계, 정신불안증, 극심/만성경련, 자율신경기능장애, 의식장애', 10000.00, 28, '2023-04-26 17:33:48');

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `category_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类代码',
  `category_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  PRIMARY KEY (`category_code`) USING BTREE,
  UNIQUE INDEX `category_code`(`category_code` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('Antiviral ', '항바이러스 ');
INSERT INTO `category` VALUES ('children', '어린이용 의약품');
INSERT INTO `category` VALUES ('Digestion', '소화제');
INSERT INTO `category` VALUES ('infect', '항감염');
INSERT INTO `category` VALUES ('skin', '피부 외용');
INSERT INTO `category` VALUES ('spirit', '정신적인 ');

-- ----------------------------
-- Table structure for order_item
-- ----------------------------
DROP TABLE IF EXISTS `order_item`;
CREATE TABLE `order_item`  (
  `order_item_id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '订单子项ID',
  `order_id` int UNSIGNED NOT NULL COMMENT '订单ID',
  `book_id` int UNSIGNED NOT NULL COMMENT '书籍ID',
  `price` decimal(10, 2) NOT NULL COMMENT '价格',
  `quantity` int UNSIGNED NOT NULL COMMENT '购买数量',
  PRIMARY KEY (`order_item_id`) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `book_id`(`book_id` ASC) USING BTREE,
  CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of order_item
-- ----------------------------
INSERT INTO `order_item` VALUES (23, 10, 1040, 13.00, 1);
INSERT INTO `order_item` VALUES (25, 12, 1065, 10000.00, 1);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `order_id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `user_id` int UNSIGNED NOT NULL COMMENT '用户ID',
  `consignee_name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '收货人姓名',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '收货地址',
  `zip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '邮政编号',
  `phone_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '联系方式',
  `status` bit(1) NOT NULL DEFAULT b'0' COMMENT '审核状态',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`order_id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (10, 2023004, 'aa', 'aa', '010000', '17897683456', b'0', NULL);
INSERT INTO `orders` VALUES (12, 2023004, '11', '22', '000001', '13792551878', b'0', NULL);

-- ----------------------------
-- Table structure for shopping_cart
-- ----------------------------
DROP TABLE IF EXISTS `shopping_cart`;
CREATE TABLE `shopping_cart`  (
  `cart_id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '购物车ID',
  `user_id` int UNSIGNED NOT NULL COMMENT '用户ID',
  `book_id` int UNSIGNED NOT NULL COMMENT '书籍ID',
  `price` decimal(10, 2) NOT NULL COMMENT '书籍价格',
  `quantity` int UNSIGNED NOT NULL COMMENT '购买数量',
  PRIMARY KEY (`cart_id`) USING BTREE,
  UNIQUE INDEX `cart_id`(`cart_id` ASC) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `book_id`(`book_id` ASC) USING BTREE,
  CONSTRAINT `shopping_cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `shopping_cart_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 76 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of shopping_cart
-- ----------------------------

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info`  (
  `user_id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户密码',
  `email` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '用户邮箱',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '用户头像',
  `join_time` datetime NULL DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2023005 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of user_info
-- ----------------------------
INSERT INTO `user_info` VALUES (2023004, 'abc', '123456', '123456@qq.com', '', '2023-04-26 00:23:59');

SET FOREIGN_KEY_CHECKS = 1;
