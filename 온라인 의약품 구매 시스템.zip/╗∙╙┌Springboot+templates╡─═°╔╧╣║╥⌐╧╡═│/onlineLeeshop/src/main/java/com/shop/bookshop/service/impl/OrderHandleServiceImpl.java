package com.shop.bookshop.service.impl;

import com.github.pagehelper.PageHelper;
import com.shop.bookshop.exception.CustomizeException;
import com.shop.bookshop.dao.BookMapper;
import com.shop.bookshop.dao.OrderItemMapper;
import com.shop.bookshop.dao.OrderMapper;
import com.shop.bookshop.dao.ShoppingCartMapper;
import com.shop.bookshop.pojo.Book;
import com.shop.bookshop.pojo.Order;
import com.shop.bookshop.pojo.OrderItem;
import com.shop.bookshop.service.OrderHandleService;
import com.shop.bookshop.util.ResultCode;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;


@Service
@Transactional(rollbackFor = Exception.class)
public class OrderHandleServiceImpl implements OrderHandleService {

    @Resource
    private OrderMapper orderMapper;
    @Resource
    private OrderItemMapper orderItemMapper;
    @Resource
    private ShoppingCartMapper shoppingCartMapper;
    @Resource
    private BookMapper bookMapper;


    @Override
    public void createOrder(Order order) {


        orderMapper.insert(order);

        for (OrderItem orderItem :order.getOrderItems()) {
            orderItem.setOrderId(order.getOrderId());
            orderItemMapper.insert(orderItem);

            shoppingCartMapper.deleteByUserIdAndBookId(order.getUserId(), orderItem.getBookId());

            Book book = bookMapper.selectByBookId(orderItem.getBookId());
            if(book.getStock()<orderItem.getQuantity()){

                throw new CustomizeException(ResultCode.FAILED,"book《"+book.getBookName()+"》out of stock");
            }

            book.setStock(book.getStock()-orderItem.getQuantity());
            bookMapper.updateByBookId(book);
        }
    }

    @Override
    public int deleteOrderById(Integer orderId) {
        orderMapper.deleteByOrderId(orderId);
        return 0;
    }


    @Override
    public List<Order> getOrdersByUserId(Integer userId, Integer page, Integer limit) {
        PageHelper.startPage(page, limit);
        List<Order> orders = orderMapper.selectByUserId(userId);
        return orders;
    }


    @Override
    public List<Order> getAllOrdersByPage(Integer page, Integer limit) {
        PageHelper.startPage(page, limit);
        List<Order> orders = orderMapper.selectAll();
        return orders;
    }
}
