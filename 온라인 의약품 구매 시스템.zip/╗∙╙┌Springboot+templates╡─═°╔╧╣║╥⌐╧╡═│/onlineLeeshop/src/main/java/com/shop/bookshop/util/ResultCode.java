package com.shop.bookshop.util;


public enum ResultCode {

    SUCCESS(0,"Successful operation"),
    FAILED(1000,"operation failed"),
    USER_NOT_LOGGED_IN(1001,"please log in first"),
    USER_NOT_FOUND(1002,"User does not exist"),
    PASSWORD_ERROR(1003,"wrong password"),
    RECORD_NOT_FOUND(1004,"Temporarily unable to find records"),
    ARGUMENT_NOT_VALID(1005,"Parameter validation error"),
    ACCESS_DENIED(1006,"no access"),
    UNKNOWN_ERROR(-1,"An error occurred, please check whether the input is legal");
    private int code;
    private String msg;

    ResultCode(int code, String msg){
        this.code=code;
        this.msg=msg;
    }
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
