package com.shop.bookshop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/admin")
public class AdminRouterController {


    @GetMapping("/user_manage")
    public String toUserManage(){
        return "admin/user";
    }


    @GetMapping({"/","/book_manage"})
    public String toBookManage(){
        return "admin/books";
    }


    @GetMapping("/category_manage")
    public String toCategoryManage(){
        return "admin/category";
    }


    @GetMapping("/order_manage")
    public String toOrderManage(){
        return "admin/order";
    }


    @GetMapping("/add_book")
    public String AddBook(){
        return "admin/add_book";
    }


    @GetMapping("/login")
    public String toAdminLogin(){
        return "admin/login";
    }

}
