package com.shop.bookshop.dao;

import com.shop.bookshop.pojo.Book;

import java.util.List;


public interface BookDisplayMapper {

    List<Book> fuzzyQueryByBookName(String bookName);
}
