package com.shop.bookshop.pojo;

import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.util.Date;

public class User {
    private Integer userId;

    @NotBlank(message = "Username can not be empty")
    @Pattern(regexp = "[0-9A-Za-z_]{3,15}",message = "Username can only be 3~15 letters, numbers or underscores")
    private String userName;

    @NotBlank(message = "password can not be blank")
    @Length(min = 6,message = "Password must be at least 6 characters")
    private String password;

    @Email(message = "E-mail format error")
    private String email;

    private String avatar;

    private Date joinTime;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar == null ? null : avatar.trim();
    }

    public Date getJoinTime() {
        return joinTime;
    }

    public void setJoinTime(Date joinTime) {
        this.joinTime = joinTime;
    }
}