package com.shop.bookshop.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;

import com.shop.bookshop.dao.BookMapper;
import com.shop.bookshop.pojo.Book;
import com.shop.bookshop.service.BookService;

@Service
public class BookServiceImpl implements BookService {
    @Resource
    private BookMapper bookMapper;
	@Override
	public Book bookSearchById(Integer bookId) {

		Book books=bookMapper.selectByBookId(bookId);
		return books;
	}


	@Override
	public List<Book> bookSearchByCode(String catrgoryCode,Integer page,Integer limit) {
			PageHelper.startPage(page, limit);
	      List<Book> books = bookMapper.selectAllByCategoryCode(catrgoryCode);
	   
	      return books;


	}

	@Override
	public int bookDeleteSearchById(Integer bookId) {

		int books=bookMapper.deleteByBookId(bookId);
		return books;
	}

	@Override
	public int bookInsert(Book record) {

		int books=bookMapper.insert(record);
                return books;
	}

	@Override
	public int bookUpdate(Book record) {

		int books=bookMapper.updateByBookId(record);
		return books;

	}



	@Override
	public List<Book> searchBooks(Book book, Integer page, Integer limit) {
		PageHelper.startPage(page,limit);
		List<Book> books = bookMapper.selectByBooks(book);
		return books;
	}
}
