package com.shop.bookshop.pojo;

import javax.validation.constraints.NotBlank;


public class Admin {
    @NotBlank(message = "Administrator account cannot be empty")
    private String adminName;
    @NotBlank(message = "password can not be blank")
    private String password;

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
