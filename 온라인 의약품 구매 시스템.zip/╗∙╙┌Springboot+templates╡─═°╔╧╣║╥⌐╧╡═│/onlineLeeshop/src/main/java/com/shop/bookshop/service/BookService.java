package com.shop.bookshop.service;

import java.util.List;

import com.shop.bookshop.pojo.Book;


   public interface BookService {

    Book bookSearchById(Integer bookId);

    List<Book> bookSearchByCode(String catrgoryCode ,Integer page,Integer limit);

    int bookDeleteSearchById(Integer bookId);

    int bookInsert(Book record);

    int bookUpdate(Book record);


    List<Book> searchBooks(Book book,Integer page,Integer limit);
}
