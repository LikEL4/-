package com.shop.bookshop.service;

import java.util.List;

import com.shop.bookshop.pojo.Order;

public interface OrderService {
    int deleteByOrderId(Integer orderId);

    int insert(Order record);

    Order selectByOrderId(Integer orderId);
    
    int updateByOrderId(Order record);

    List<Order> selectAll();

    List<Order> selectByUserId(Integer userId);


    List<Order> searchOrders(Order order,Integer page,Integer limit);
}
