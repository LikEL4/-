package com.shop.bookshop.controller;

import com.shop.bookshop.exception.CustomizeException;
import com.shop.bookshop.pojo.ShoppingCart;
import com.shop.bookshop.pojo.User;
import com.shop.bookshop.service.ShoppingCartService;
import com.shop.bookshop.util.ResultCode;
import com.shop.bookshop.util.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping("/cart")
public class ShoppingCartController {

    @Autowired
    private ShoppingCartService shoppingCartService;

    @GetMapping("/list")
    public ResultVO getCartByUserId(HttpSession session) {
        User user = (User) session.getAttribute("user");
        List<ShoppingCart> carts = shoppingCartService.getShoppingCartsByUserId(user.getUserId());
        return new ResultVO(ResultCode.SUCCESS, carts);
    }


    @PutMapping("/list/{cartId}")
    public ResultVO updateCartItem(@PathVariable("cartId") Integer cartId,Integer quantity) {
        if(quantity<=0){
            throw new CustomizeException(ResultCode.FAILED,"The number of purchases must be greater than zero");
        }
        if(quantity>10){
            throw new CustomizeException(ResultCode.FAILED,"limit one's purchase to 10 pieces per item");
        }
        ShoppingCart cart = new ShoppingCart();
        cart.setCartId(cartId);
        cart.setQuantity(quantity);
        shoppingCartService.updateShoppingCart(cart);
        return new ResultVO(ResultCode.SUCCESS);
    }


    @PostMapping("/list")
    public ResultVO addToShoppingCart(@Valid ShoppingCart cart, HttpSession session) {
        User user = (User) session.getAttribute("user");
        cart.setUserId(user.getUserId());
        shoppingCartService.addToShoppingCart(cart);
        return new ResultVO(ResultCode.SUCCESS);
    }


    @DeleteMapping("/list/{cartId}")
    public ResultVO deleteCartItem(@PathVariable("cartId") Integer cartId) {
        shoppingCartService.deleteShoppingCartByCartId(cartId);
        return new ResultVO(ResultCode.SUCCESS);
    }


    @DeleteMapping("/list")
    public ResultVO deleteCartItem(@RequestBody int[] cartIds) {
        shoppingCartService.deleteShoppingCarts(cartIds);
        return new ResultVO(ResultCode.SUCCESS);
    }


}
