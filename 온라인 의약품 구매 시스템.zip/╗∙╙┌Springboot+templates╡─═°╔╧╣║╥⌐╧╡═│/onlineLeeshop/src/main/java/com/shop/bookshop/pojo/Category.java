package com.shop.bookshop.pojo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class Category {
    @NotBlank(message = "Classification code cannot be empty")
    @Pattern(regexp = "[a-zA-Z]+",message = "Classification codes can only be letters")
    private String categoryCode;

    @NotBlank(message = "Category name is not empty")
    private String categoryName;

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode == null ? null : categoryCode.trim();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName == null ? null : categoryName.trim();
    }

    @Override
    public String toString() {
        return "Category{" +
                "categoryCode='" + categoryCode + '\'' +
                ", categoryName='" + categoryName + '\'' +
                '}';
    }
}