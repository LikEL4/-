layui.use(['element', 'jquery', 'layer', 'laytpl','laypage','form','table'], function() {
	var $ = layui.jquery,
		layer = layui.layer,
		laytpl = layui.laytpl,
		laypage=layui.laypage,
		form=layui.form,
		element = layui.element,
		table = layui.table;
	  
	  table.render({
	    elem: '#order_tb'
	    ,url:'/user_center/orders'
	    ,cols: [[
	      {field:'orderId', title:'order number', width:120, fixed: 'left',unresize: true,  sort: true}
	      ,{field:'consigneeName', title:'Consignee name', width:120}
	      ,{field:'address', title:'Shipping address', width:200}
	      ,{field:'zip', title:'zip code', width:100, sort: true}
	      ,{field:'phoneNumber', title:'Contact information', width:120}
	      ,{field:'status', title:'Order Status',width:90,templet: function(res){
			  if(res.status){
				  return '<span class="layui-badge layui-bg-blue">Shipped</span>';
			  }
	        return '<span class="layui-badge">to be delivered</span>';
	      }}
	      ,{field:'createTime', title:'creation time', width:180}
	      ,{fixed: 'right', title:'operate', toolbar: '#order_tb_bar', width:160}
	    ]]
	    ,page: true
		,limit:5
		,limits:[5,15,30,60,100]
	  });
	  
	  

	  table.on('tool(order_tb)', function(obj){
	    var data = obj.data;
	    if(obj.event === 'del'){
	      layer.confirm('Do you really want to delete this order record?', function(index){
			  $.ajax({
				  url:'/user_center/orders/'+data.orderId,
				  type:'delete',
				  dataType:'json',
				  success:function (res) {
					if(res.code!=0){
						return layer.msg(res.msg, {icon: 2});
					}
					  return layer.msg("successfully deleted", {icon: 1},function () {
						  obj.del();
						  $("#order-items").html("");
					  });
				  },
				  error:function () {
					  return layer.msg("Server error, please try again later", {icon: 2});
				  }
			  });
			  layer.close(index);
	      });
	    } else if(obj.event === 'detail'){

			laytpl($("#order-item-tpl").html()).render(data.orderItems,function(html){
				$("#order-items").html(html);
			});
	    }
	  });
	  
	  
});