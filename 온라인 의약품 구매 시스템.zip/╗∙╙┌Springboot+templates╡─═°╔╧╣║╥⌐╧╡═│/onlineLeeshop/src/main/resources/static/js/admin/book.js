layui.use(['table', 'form', 'jquery', 'layer', 'upload','element'], function() {
	var table = layui.table,
		$ = layui.jquery,
		layer = layui.layer,
		upload = layui.upload,
		element =layui.element,
		form = layui.form;

	var book_tb = table.render({
		elem: '#book_tb',
		url: '/book/searchcode',
		cols: [
			[{
				field: 'bookId',
				title: 'ID',
				width: 110,
				fixed: 'left',
				sort: true
			}, {
				field: 'bookName',
				title: 'drug name',
				width: 120
			}, {
				field: 'categoryName',
				title: 'Classification',
				width: 80,
				templet: function(res) {
					return '<span class="layui-badge-rim">' + res.category.categoryName + '</span>';
				}
			}, {
				field: 'description',
				title: 'Introduction',
				width: 120
			}, {
				field: 'isbn',
				title: 'Leecode',
				width: 120,
				templet: function(res) {
					return '<em>' + res.isbn + '</em>'
				}
			}, {
				field: 'press',
				title: 'manufacturers',
				width: 120
			}, {
				field: 'author',
				title: 'validity period',
				width: 100
			}, {
				field: 'pubDate',
				title: 'Production Date',
				width: 120
			}, {
				field: 'price',
				title: 'Price',
				width: 80
			},  {
				field: 'stock',
				title: 'Stock',
				width: 80
			}, {
				field: 'createTime',
				title: 'Added time',
				width: 120
			}, {
				fixed: 'right',
				title: 'operate',
				toolbar: '#barDemo',
				width: 150
			}]
		],
		page: true,
		height: 500
	});

	



	table.on('tool(book_tb)', function(obj) {
		var data = obj.data;
		if (obj.event === 'del') {
			layer.confirm('really delete it?', {
				icon: 3
			}, function(index) {
				$.ajax({
					url: '/book/delete',
					type: 'post',
					data: {bookId:data.bookId},
					dataType: 'json',
					success: function(res) {
						if (res.code != 0) {
							return layer.msg("failed to delete：" + res.msg, {
								icon: 2
							});
						}
						return layer.msg("successfully deleted", {
							icon: 1,
							time: 1300
						}, function() {
							obj.del();
						});
					}
				});
				layer.close(index);
			});
		} else if (obj.event === 'edit') {
			layer.open({
				type: 1,
				title: 'edit books',
				content: $("#book_form_tmpl").html(),
				area: ['500px'],
				btn: ['renew'],
				yes: function(index1) {
					let new_data=form.val("book-form");
					$.ajax({
						url: '/book/update',
						type: 'post',
						data: new_data,
						dataType: 'json',
						success: function(res) {
							if (res.code != 0) {
								return layer.msg(res.msg, {
									icon: 2
								});
							}
							return layer.msg("update completed", {
								icon: 1,
								time: 1300
							}, function() {
								obj.update(new_data);
								layer.close(index1);
							});
						}
					});
				},
				success: function() {
					form.render(null, "book-form");
					$("#bookId").attr("disabled", true);
					$.getJSON("/category/searchall", function(res) {
						if (res.code != 0) {
							return;
						}
						$.each(res.data, function(index, item) {
							$("#categoryCode").append('<option value="' + item.categoryCode + '">' + item.categoryName +
								'</option> ');
						});

						form.val("book-form", data);
						form.render();
					});
				}
			});
		}
	});

	

	var book_tb_this;
	form.on('submit(search_btn)', function(data) {
		if (book_tb_this != null) {
			book_tb_this.where = {};
		}
		book_tb.reload({
			url: '/book/search',
			where: data.field,
			page: {
				curr: 1
			},
			done: function() {
				book_tb_this = this;
			}
		});
		return false;
	});

});
