layui.use(['element', 'jquery', 'layer', 'laytpl', 'laypage', 'form'], function () {
    var $ = layui.jquery,
        layer = layui.layer,
        laytpl = layui.laytpl,
        laypage = layui.laypage,
        form = layui.form,
        element = layui.element;


    getShoppingCart();


    function getShoppingCart() {
        $("#shopping-carts").html("");
        var queryStr = window.location.search;
        var userId = queryStr.substring(queryStr.lastIndexOf("=") - 1);

        $.getJSON("/cart/list", function (res) {
            if(res.code!=0){
               return layer.msg(res.msg,{icon:2});
            }
            if (res.data.length== 0) {
                $("#shopping-carts").html('<div class="cart-tip">Your shopping cart is empty~</div>');
                $("#buyBtn").hide();
                $("#deleteSelectedBtn").hide();
                return;
            }
            laytpl($("#shopping-carts-tpl").html()).render(res.data, function (html) {
                $("#shopping-carts").html(html);
            });
            form.render('checkbox');
        });
    }



    form.on('checkbox(selectAll)', function (data) {

        if (data.elem.checked) {

            $.each($("input[name='cartId']"), function (index, item) {
                $(item)[0].checked = true;
            });
            form.render('checkbox');
        } else {

            $.each($("input[name='cartId']"), function (index, item) {
                $(item)[0].checked = false;
            });
            form.render('checkbox');
        }
    });

    form.on('checkbox(selectOne)', function (data) {
        var flag = true;
        $.each($("input[name='cartId']"), function (index, item) {
            if (!$(item)[0].checked) {
                flag = false;
            }
        });
        if (flag) {
            $("input[name='selectAll']")[0].checked = true;
        } else {
            $("input[name='selectAll']")[0].checked = false;
        }
        form.render('checkbox');
    });



    $("#buyBtn").click(function () {
        let data = [];

        $.each($("input[name='cartId']"), function (index, item) {
            let cartItem = {};
            if ($(item)[0].checked) {

                let cartId = $(item).val();
                cartItem['cartId'] = cartId;

                cartItem['bookId'] = $(item).attr("c-bookId");

                cartItem['price'] = $(item).attr("c-price");

                cartItem['quantity'] = $("#quantity-" + cartId).val();
                data.push(cartItem);
            }
        });
        if(data.length==0){
           return  layer.msg("At least one must be selected to purchase",{icon: 2});
        }

        order_submit_popup(data);
    });



    window.deleteByCartId = function (cartId) {
        $.ajax({
            url:'/cart/list/'+cartId,
            type:'delete',
            dataType:'json',
            success:function (res) {
                if (res.code != 0) {
                    return layer.msg(res.msg,{icon:2});
                }
                return layer.msg("successfully deleted", {icon: 1, time: 1300}, function () {

                    getShoppingCart();
                });
            },
            error:function () {
                return layer.msg("server error",{icon:2});
            }
        });
    }



    $("#deleteSelectedBtn").click(function () {
        let data = [];
        $.each($("input[name='cartId']"), function (index, item) {
            if ($(item)[0].checked) {

                data.push($(item).val());
            }
        });
        $.ajax({
            url:'/cart/list',
            type:'delete',
            contentType:'application/json',
            data:JSON.stringify(data),
            dataType:'json',
            success:function (res) {
                if (res.code != 0) {
                    return layer.msg(res.msg,{icon:2});
                }
                return layer.msg("successfully deleted", {icon: 1, time: 1300}, function () {

                    getShoppingCart();
                });
            },
            error:function () {
                return layer.msg("server error",{icon:2});
            }
        });
    });


    window.checkAndCalculate = function (obj, cartId, price) {
        var qty = $(obj).val();
        if (qty == '') {
            $(obj).val(1);
            qty=1;
        }
        $("#total-" + cartId).text(calculate(price, qty));
        $.ajax({
            url:'/cart/list/'+cartId,
            type:'put',
            data:{quantity:qty},
            dataType:'json',
            success:function (res) {
                if(res.code!=0){
                    return layer.msg(res.msg,{icon:2});
                }
            },
            error:function () {
                return layer.msg("server error",{icon:2});
            }
        });
    }

});