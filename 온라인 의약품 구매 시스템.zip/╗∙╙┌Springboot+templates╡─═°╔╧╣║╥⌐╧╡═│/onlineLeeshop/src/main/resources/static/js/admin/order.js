layui.use(['element', 'jquery', 'layer', 'laytpl', 'laypage', 'form', 'table'], function() {
	var $ = layui.jquery,
		layer = layui.layer,
		laytpl = layui.laytpl,
		laypage = layui.laypage,
		form = layui.form,
		element = layui.element,
		table = layui.table;

	var orderTb=table.render({
		elem: '#order_tb',
		url: '/order/list',
		cols: [
			[{
				field: 'orderId',
				title: 'order number',
				width: 120,
				fixed: 'left',
				unresize: true,
				sort: true
			}, {
				field: 'consigneeName',
				title: 'Consignee name',
				width: 120
			}, {
				field: 'address',
				title: 'Shipping address',
				width: 220
			}, {
				field: 'zip',
				title: 'zip code',
				width: 100,
				sort: true
			}, {
				field: 'phoneNumber',
				title: 'Contact information',
				width: 120
			}, {
				field: 'status',
				title: 'Order Status',
				width: 90,
				templet: function(res) {
					if (res.status) {
						return '<span class="layui-badge layui-bg-blue">Shipped</span>';
					}
					return '<span class="layui-badge">to be delivered</span>';
				}
			}, {
				field: 'createTime',
				title: 'creation time',
				width: 120
			}, {
				fixed: 'right',
				title: 'operate',
				toolbar: '#order_tb_bar',
				width: 200
			}]
		],
		page: true,
		height: 450
	});



	table.on('tool(order_tb)', function(obj) {
		var data = obj.data;
		if (obj.event === 'del') {
			layer.confirm('really delete it?', function(index) {
				$.ajax({
					url:'/order/list/'+data.orderId,
					type:'delete',
					dataType:'json',
					success:function (res) {
						if(res.code!=0){
							return layer.msg(res.msg, {icon: 2});
						}
						return layer.msg("successfully deleted", {icon: 1},function () {
							obj.del();
							$("#order-items").html("");
						});
					},
					error:function () {
						return layer.msg("Server error, please try again later", {icon: 2});
					}
				});
				layer.close(index);
			});
		} else if (obj.event === 'detail') {
			laytpl($("#order-item-tpl").html()).render(data.orderItems, function(html) {
				$("#order-items").html(html);
			});
		}else{
			layer.open({
				type: 1,
				title: 'edit order',
				content: $("#order-edit-tpl").html(),
				area: ['350px'],
				btn: ['update'],
				yes: function(index1) {
					let new_data=form.val("order-edit-form");
					if(new_data.status==null){
						new_data.status=false;
					}
					console.log(new_data);
					$.ajax({
						url: '/order/list/'+data.orderId,
						type: 'PUT',
						data: JSON.stringify(new_data),
						contentType: 'application/json',
						dataType: 'json',
						success: function(res) {
							if (res.code != 0) {
								return layer.msg(res.msg, {
									icon: 2
								});
							}
							return layer.msg("update completed", {
								icon: 1,
								time: 1300
							}, function() {
								obj.update(new_data);
								layer.close(index1);
							});
						}
					});
				},
				success: function() {

					form.val("order-edit-form", data);
					form.render();
				}
			});
		}
	});


	var order_tb_this;
	form.on('submit(search_btn)', function(data) {
		if (order_tb_this != null) {
			order_tb_this.where = {};
		}
		orderTb.reload({
			url: '/order/search',
			where: data.field,
			page: {
				curr: 1
			},
			done: function() {
				order_tb_this = this;
			}
		});
		return false;
	});


});
